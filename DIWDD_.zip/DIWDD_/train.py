import argparse
import os

import torch
from torch.utils.data import DataLoader

from utils import init_env
from utils.collate_utils import collate
from utils.import_utils import get_obj_from_str, instantiate_from_config, recurse_instantiate_from_config
from utils.init_utils import add_args
from utils.train_utils import set_random_seed
from utils.trainer import Trainer


DEFAULT_REIN_CONFIG = 'Rein/configs/rein_config.py'
DEFAULT_REIN_CHECKPOINT = 'Rein/output/Rein_2_40000_0.7408/best_mIoU_iter_38000.pth'
DEFAULT_BACKBONE_CHECKPOINT = 'checkpoints/dinov2_converted.pth'


set_random_seed(42)


def build_loaders(cfg):
    train_dataset = instantiate_from_config(cfg.train_dataset)
    val_dataset = instantiate_from_config(cfg.test_dataset.NEUSW1700)

    train_loader = DataLoader(
        train_dataset,
        batch_size=cfg.batch_size,
        shuffle=True,
        num_workers=cfg.num_workers,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=cfg.batch_size,
        collate_fn=collate,
    )
    return train_loader, val_loader


def apply_result_name(cfg):
    if not cfg.result_name:
        return
    result_name = os.path.basename(cfg.result_name)
    if result_name != cfg.result_name:
        raise ValueError(f'--result_name must be a folder name, got: {cfg.result_name}')
    cfg.results_folder = os.path.join(cfg.results_folder, result_name)


def apply_online_edge_config(cfg):
    if not cfg.use_online_edge_inference:
        return
    cfg.test_dataset.NEUSW1700.params.edge_root = None
    cfg.rein_config = DEFAULT_REIN_CONFIG
    cfg.rein_checkpoint = DEFAULT_REIN_CHECKPOINT
    cfg.backbone_checkpoint = DEFAULT_BACKBONE_CHECKPOINT


def parse_config():
    parser = argparse.ArgumentParser()
    parser.add_argument('--resume', type=str, default=None)
    parser.add_argument('--pretrained', type=str, default=None)
    parser.add_argument('--fp16', action='store_true')
    parser.add_argument('--results_folder', type=str, default='output/trian_result')
    parser.add_argument('--result_name', type=str, default=None)
    parser.add_argument('--num_epoch', type=int, default=150)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--gradient_accumulate_every', type=int, default=1)
    parser.add_argument('--num_workers', type=int, default=8)
    parser.add_argument('--lr_min', type=float, default=1e-6)
    parser.add_argument('--val_every_epochs', type=int, default=1)
    parser.add_argument('--use_online_edge_inference', action='store_true')
    return add_args(parser)


if __name__ == '__main__':
    cfg = parse_config()
    apply_result_name(cfg)
    apply_online_edge_config(cfg)

    model = recurse_instantiate_from_config(cfg.model)
    diffusion_model = instantiate_from_config(cfg.diffusion_model, model=model)
    train_loader, val_loader = build_loaders(cfg)

    optimizer = instantiate_from_config(cfg.optimizer, params=model.parameters())
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=cfg.num_epoch,
        eta_min=cfg.lr_min,
    )

    trainer = Trainer(
        diffusion_model,
        train_loader,
        val_loader,
        train_val_forward_fn=get_obj_from_str(cfg.train_val_forward_fn),
        gradient_accumulate_every=cfg.gradient_accumulate_every,
        results_folder=cfg.results_folder,
        optimizer=optimizer,
        scheduler=scheduler,
        train_num_epoch=cfg.num_epoch,
        amp=cfg.fp16,
        cfg=cfg,
    )
    if cfg.resume or cfg.pretrained:
        trainer.load(resume_path=cfg.resume, pretrained_path=cfg.pretrained)
    trainer.train()
