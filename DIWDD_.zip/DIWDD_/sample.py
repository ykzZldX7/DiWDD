import argparse
import os
import time
from pathlib import Path

import torch
import torch.nn.functional as F
from torch import nn
from torch.utils.data import DataLoader

from utils import init_env
from utils.collate_utils import collate
from utils.import_utils import get_obj_from_str, instantiate_from_config, recurse_instantiate_from_config
from utils.init_utils import add_args
from utils.train_utils import set_random_seed
from utils.trainer import Trainer


DEFAULT_REIN_CONFIG = 'Rein/configs/rein_config.py'
DEFAULT_REIN_CHECKPOINT = 'Rein/output/Rein_2_40000_0.7408/best_mIoU_iter_38000.pth'
DEFAULT_BACKBONE_CHECKPOINT = 'checkpoints/dinov2_converted.pth'


set_random_seed(7)


class InferenceProfiler:
    def __init__(self, accelerator, flops_batches=1):
        self.accelerator = accelerator
        self.flops_batches = max(0, flops_batches)
        self.total_time = 0.0
        self.total_images = 0
        self.total_flops = 0.0
        self.flops_images = 0
        self._batch_start = None
        self._batch_size = 0
        self._handles = []
        self._current_flops = 0.0
        self._profile_flops_this_batch = False
        self._count_latency_this_batch = False

    @staticmethod
    def _sync(device):
        if torch.cuda.is_available() and device.type == 'cuda':
            torch.cuda.synchronize(device)

    def start_batch(self, batch_size, device):
        self._batch_size = int(batch_size)
        self._profile_flops_this_batch = self.flops_images == 0 and self.flops_batches > 0
        self._count_latency_this_batch = not self._profile_flops_this_batch
        if self._count_latency_this_batch:
            self._sync(device)
            self._batch_start = time.perf_counter()
        else:
            self._batch_start = None

    def end_batch(self, device):
        if self._count_latency_this_batch:
            self._sync(device)
            elapsed = time.perf_counter() - self._batch_start
            self.total_time += elapsed
            self.total_images += self._batch_size
        self._batch_start = None
        self._count_latency_this_batch = False

    def profile_call(self, module, fn):
        if not self._profile_flops_this_batch:
            return fn()

        self._current_flops = 0.0
        self._register_hooks(module)
        try:
            return fn()
        finally:
            self._remove_hooks()
            self.total_flops += self._current_flops
            self.flops_images += self._batch_size

    def summary(self):
        total_time_tensor = torch.tensor([self.total_time], device=self.accelerator.device, dtype=torch.float64)
        total_images_tensor = torch.tensor([self.total_images], device=self.accelerator.device, dtype=torch.float64)
        total_flops_tensor = torch.tensor([self.total_flops], device=self.accelerator.device, dtype=torch.float64)
        flops_images_tensor = torch.tensor([self.flops_images], device=self.accelerator.device, dtype=torch.float64)

        total_time = self.accelerator.gather(total_time_tensor).sum().item()
        total_images = self.accelerator.gather(total_images_tensor).sum().item()
        total_flops = self.accelerator.gather(total_flops_tensor).sum().item()
        flops_images = self.accelerator.gather(flops_images_tensor).sum().item()

        fps = total_images / total_time if total_time > 0 else 0.0
        latency_ms = total_time * 1000.0 / total_images if total_images > 0 else 0.0
        flops_per_image = total_flops / flops_images if flops_images > 0 else 0.0
        return {
            'flops': flops_per_image,
            'fps': fps,
            'latency_ms': latency_ms,
            'total_time': total_time,
            'total_images': total_images,
            'flops_images': flops_images,
        }

    def _register_hooks(self, module):
        for child in module.modules():
            if isinstance(child, nn.Conv2d):
                self._handles.append(child.register_forward_hook(self._conv_hook))
            elif isinstance(child, nn.Linear):
                self._handles.append(child.register_forward_hook(self._linear_hook))
            elif isinstance(child, (nn.BatchNorm2d, nn.LayerNorm, nn.GroupNorm)):
                self._handles.append(child.register_forward_hook(self._norm_hook))
            elif child.__class__.__name__ == 'Attention':
                self._handles.append(child.register_forward_hook(self._attention_hook))

    def _remove_hooks(self):
        for handle in self._handles:
            handle.remove()
        self._handles = []

    def _conv_hook(self, module, inputs, output):
        if not torch.is_tensor(output):
            return
        batch_size = output.shape[0]
        out_channels = output.shape[1]
        out_h, out_w = output.shape[-2:]
        kernel_ops = module.kernel_size[0] * module.kernel_size[1] * (module.in_channels // module.groups)
        bias_ops = 1 if module.bias is not None else 0
        self._current_flops += batch_size * out_channels * out_h * out_w * (2 * kernel_ops + bias_ops)

    def _linear_hook(self, module, inputs, output):
        if not torch.is_tensor(output):
            return
        bias_ops = 1 if module.bias is not None else 0
        self._current_flops += output.numel() * (2 * module.in_features + bias_ops)

    def _norm_hook(self, module, inputs, output):
        if torch.is_tensor(output):
            self._current_flops += 2 * output.numel()

    def _attention_hook(self, module, inputs, output):
        if not inputs or not torch.is_tensor(inputs[0]):
            return
        x = inputs[0]
        if x.ndim != 3:
            return
        batch_size, num_tokens, channels = x.shape
        num_heads = getattr(module, 'num_heads', 1)
        head_dim = channels // num_heads
        key_tokens = num_tokens
        sr_ratio = getattr(module, 'sr_ratio', 1)
        if sr_ratio > 1 and len(inputs) >= 3:
            h, w = int(inputs[1]), int(inputs[2])
            key_tokens = 1 + (h // sr_ratio) * (w // sr_ratio)

        qk_flops = 2 * batch_size * num_heads * num_tokens * key_tokens * head_dim
        av_flops = 2 * batch_size * num_heads * num_tokens * key_tokens * head_dim
        self._current_flops += qk_flops + av_flops


def build_loader(cfg):
    dataset = instantiate_from_config(cfg.test_dataset.NEUSW1700)
    return DataLoader(dataset, batch_size=cfg.batch_size, collate_fn=collate)


def apply_result_name(cfg):
    if cfg.result_name:
        cfg.results_folder = os.path.join(cfg.results_folder, os.path.basename(cfg.result_name))


def validate_checkpoint(checkpoint):
    if checkpoint is None:
        raise ValueError('--checkpoint is required for sampling.')
    if not os.path.isfile(checkpoint):
        raise FileNotFoundError(f'Checkpoint not found: {checkpoint}')


def build_rein_inference(device):
    from utils.rein_online_inference import ReinOnlineInference

    return ReinOnlineInference(
        config_path=DEFAULT_REIN_CONFIG,
        checkpoint_path=DEFAULT_REIN_CHECKPOINT,
        backbone_path=DEFAULT_BACKBONE_CHECKPOINT,
        device=device,
    )


def parse_config():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=str, default=None)
    parser.add_argument('--fp16', action='store_true')
    parser.add_argument('--results_folder', type=str, default='output/test_result')
    parser.add_argument('--result_name', type=str, default=None)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--num_sample_steps', type=int, default=None)
    parser.add_argument('--target_dataset', type=str, default='NEUSW1700')
    parser.add_argument('--use_online_edge_inference', action='store_true')
    parser.add_argument('--pvt_cache_steps', type=int, default=1)
    parser.add_argument('--use_skip_sampling', action='store_true')
    parser.add_argument('--skip_sampling_stride', type=int, default=2)
    return add_args(parser)


def build_cached_forward(
        forward_fn,
        pvt_cache_steps,
        use_skip_sampling=False,
        skip_sampling_stride=2,
        profiler=None):
    def cached_forward(model, gt_long=None, gt_one_hot=None, image=None, edge_map=None, **kwargs):
        if model.training:
            kwargs['pvt_cache_steps'] = pvt_cache_steps
            return forward_fn(
                model,
                gt_long=gt_long,
                gt_one_hot=gt_one_hot,
                image=image,
                edge_map=edge_map,
                **kwargs,
            )

        gt_sizes = kwargs.pop('gt_sizes', None)
        kwargs['pvt_cache_steps'] = pvt_cache_steps
        kwargs['use_skip_sampling'] = use_skip_sampling
        kwargs['skip_sampling_stride'] = skip_sampling_stride

        if profiler is None:
            pred_tensor = model.sample(image, edge_map=edge_map, **kwargs)
        else:
            profiler.start_batch(image.shape[0], image.device)
            try:
                pred_tensor = profiler.profile_call(
                    model,
                    lambda: model.sample(image, edge_map=edge_map, **kwargs),
                )
            finally:
                profiler.end_batch(image.device)

        if gt_sizes is None:
            pred_list = [pred for pred in pred_tensor]
        else:
            pred_list = [
                F.interpolate(pred.unsqueeze(0), size=size, mode='bilinear', align_corners=False).squeeze(0)
                for pred, size in zip(pred_tensor, gt_sizes)
            ]

        return {
            'image': image,
            'pred': pred_list,
            'gt': gt_long if gt_long is not None else None,
        }

    return cached_forward


if __name__ == '__main__':
    cfg = parse_config()
    if cfg.target_dataset != 'NEUSW1700':
        raise ValueError(f'Only NEUSW1700 is supported, got: {cfg.target_dataset}')
    if cfg.pvt_cache_steps < 1:
        raise ValueError(f'--pvt_cache_steps must be >= 1, got: {cfg.pvt_cache_steps}')
    if cfg.skip_sampling_stride < 1:
        raise ValueError(f'--skip_sampling_stride must be >= 1, got: {cfg.skip_sampling_stride}')

    validate_checkpoint(cfg.checkpoint)
    apply_result_name(cfg)

    if cfg.use_online_edge_inference:
        cfg.test_dataset.NEUSW1700.params.edge_root = None
    if cfg.num_sample_steps is not None:
        cfg.diffusion_model.params.num_sample_steps = cfg.num_sample_steps

    cfg.diffusion_model.name = 'model.SimpleDiffSef_pvt_cache.CondGaussianDiffusion'

    test_loader = build_loader(cfg)
    model = recurse_instantiate_from_config(cfg.model)
    diffusion_model = instantiate_from_config(cfg.diffusion_model, model=model)
    optimizer = instantiate_from_config(cfg.optimizer, params=model.parameters())
    train_val_forward_fn = build_cached_forward(
        get_obj_from_str(cfg.train_val_forward_fn),
        cfg.pvt_cache_steps,
        use_skip_sampling=cfg.use_skip_sampling,
        skip_sampling_stride=cfg.skip_sampling_stride,
    )

    trainer = Trainer(
        diffusion_model,
        train_loader=None,
        test_loader=None,
        train_val_forward_fn=train_val_forward_fn,
        optimizer=optimizer,
        results_folder=cfg.results_folder,
        amp=cfg.fp16,
        cfg=cfg,
    )
    trainer.load(pretrained_path=cfg.checkpoint)

    rein_inference = build_rein_inference(trainer.accelerator.device) if cfg.use_online_edge_inference else None
    test_loader = trainer.accelerator.prepare(test_loader)
    inference_profiler = InferenceProfiler(trainer.accelerator)
    trainer.train_val_forward_fn = build_cached_forward(
        get_obj_from_str(cfg.train_val_forward_fn),
        cfg.pvt_cache_steps,
        use_skip_sampling=cfg.use_skip_sampling,
        skip_sampling_stride=cfg.skip_sampling_stride,
        profiler=inference_profiler,
    )

    save_to = Path(cfg.results_folder)
    os.makedirs(save_to, exist_ok=True)

    metrics, _ = trainer.val_semantic(
        model=trainer.model,
        test_data_loader=test_loader,
        accelerator=trainer.accelerator,
        num_classes=7,
        save_to=save_to,
        rein_inference=rein_inference,
    )

    trainer.accelerator.wait_for_everyone()
    trainer.accelerator.print(f'NEUSW1700 miou: {metrics["miou"]}')
    profile_metrics = inference_profiler.summary()
    trainer.accelerator.print(
        'Inference profile: '
        f'FLOPs={profile_metrics["flops"] / 1e9:.4f} GFLOPs/image, '
        f'FPS={profile_metrics["fps"]:.4f} images/s, '
        f'Latency={profile_metrics["latency_ms"]:.4f} ms/image'
    )
    trainer.accelerator.print(
        'Inference profile scope: model.sample with PVT cache only; '
        'FLOPs are hook-based estimates from the first inference batch; '
        'FPS/Latency exclude the FLOPs hook batch.'
    )
    trainer.accelerator.wait_for_everyone()
