import os
import albumentations
from PIL import Image
import torch.utils.data as data
import torchvision.transforms as transforms
import random
import numpy as np
from PIL import ImageEnhance
import torch
import torch.nn.functional as F

# several data augumentation strategies
'''
对输入的图像和标签进行随机翻转。有四种可能：不翻转、水平翻转、垂直翻转、水平加垂直翻转。
输入参数:
    img (PIL.Image): 原始图像。
    label (PIL.Image): 对应的标签图像。
输出:
    一个元组 (img, label)，包含经过同样翻转操作后的图像和标签。
'''
def cv_random_flip(img, label):
    flip_flag = random.randint(0, 3)
    if flip_flag == 1:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
        label = label.transpose(Image.FLIP_LEFT_RIGHT)
    elif flip_flag == 2:
        img = img.transpose(Image.FLIP_TOP_BOTTOM)
        label = label.transpose(Image.FLIP_TOP_BOTTOM)
    elif flip_flag == 3:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
        label = label.transpose(Image.FLIP_LEFT_RIGHT)
        img = img.transpose(Image.FLIP_TOP_BOTTOM)
        label = label.transpose(Image.FLIP_TOP_BOTTOM)
    return img, label

'''
作用: 对图像和标签进行随机裁剪。它会在图像边界附近随机确定一个裁剪窗口，然后进行裁剪。
输入参数:
    image (PIL.Image): 原始图像。
    label (PIL.Image): 对应的标签图像。
输出:
    一个元组 (image, label)，包含经过同样裁剪操作后的图像和标签。
'''
def randomCrop(image, label):
    border = 30
    image_width = image.size[0]
    image_height = image.size[1]
    crop_win_width = np.random.randint(image_width - border, image_width)
    crop_win_height = np.random.randint(image_height - border, image_height)
    random_region = (
        (image_width - crop_win_width) >> 1, (image_height - crop_win_height) >> 1, (image_width + crop_win_width) >> 1,
        (image_height + crop_win_height) >> 1)
    return image.crop(random_region), label.crop(random_region)

'''
作用: 以 20% 的概率对图像和标签进行随机旋转，旋转角度在 -15 到 +15 度之间。
输入参数:
    image (PIL.Image): 原始图像。
    label (PIL.Image): 对应的标签图像。
输出:
    一个元组 (image, label)，可能经过了旋转，也可能保持原样。
'''
def randomRotation(image, label):
    mode = Image.BICUBIC
    if random.random() > 0.8:
        random_angle = np.random.randint(-15, 15)
        image = image.rotate(random_angle, mode)
        # label = label.rotate(random_angle, mode)
        label = label.rotate(random_angle, Image.NEAREST)
    return image, label

'''
作用: 对输入图像进行颜色增强，随机调整其亮度、对比度、色彩饱和度和清晰度。注意：此操作只对图像进行，不对标签进行。
输入参数:
    image (PIL.Image): 原始图像。
输出:
    image (PIL.Image): 经过颜色增强后的图像。
'''
def colorEnhance(image):
    bright_intensity = random.randint(5, 15) / 10.0
    image = ImageEnhance.Brightness(image).enhance(bright_intensity)
    contrast_intensity = random.randint(5, 15) / 10.0
    image = ImageEnhance.Contrast(image).enhance(contrast_intensity)
    color_intensity = random.randint(0, 20) / 10.0
    image = ImageEnhance.Color(image).enhance(color_intensity)
    sharp_intensity = random.randint(0, 30) / 10.0
    image = ImageEnhance.Sharpness(image).enhance(sharp_intensity)
    return image

'''
作用: 对图像添加高斯噪声。
输入参数:
    image (PIL.Image): 原始图像。
    mean (float): 噪声的均值。
    sigma (float): 噪声的标准差。
输出:
    image (PIL.Image): 添加了高斯噪声后的图像。
'''
def randomGaussian(image, mean=0.1, sigma=0.35):
    def gaussianNoisy(im, mean=mean, sigma=sigma):
        for _i in range(len(im)):
            im[_i] += random.gauss(mean, sigma)
        return im

    img = np.asarray(image)
    width, height = img.shape
    img = gaussianNoisy(img[:].flatten(), mean, sigma)
    img = img.reshape([width, height])
    return Image.fromarray(np.uint8(img))

'''
作用: 对图像添加椒盐噪声（随机添加纯黑或纯白的像素点）。
输入参数:
    img (PIL.Image): 原始图像。
输出:
    image (PIL.Image): 添加了椒盐噪声后的图像。
'''
def randomPeper(img):
    img = np.array(img)
    noiseNum = int(0.0015 * img.shape[0] * img.shape[1])
    for i in range(noiseNum):

        randX = random.randint(0, img.shape[0] - 1)

        randY = random.randint(0, img.shape[1] - 1)

        if random.randint(0, 1) == 0:

            img[randX, randY] = 0

        else:

            img[randX, randY] = 255
    return Image.fromarray(img)

# dataset for training
# 用于训练集dataset的类
class PolypObjDataset(data.Dataset):
    def __init__(self,
                 image_root, # (str): 训练图像所在的文件夹路径。
                 gt_root,   # (str): 训练真值标签所在的文件夹路径。
                 edge_root, # 边缘引导，现在可为None以支持在线边缘推理
                 trainsize, # (int): 训练时输入网络的图像尺寸（例如 352）。
                 mean=None, # (list, optional): 图像归一化用的均值，默认为 ImageNet 的均值。
                 std=None,  #  (list, optional): 图像归一化用的标准差，默认为 ImageNet 的标准差。
                 randomPeper=True,  # (bool):是否启用椒盐噪声增强。
                 boundary_modification=False,   # (bool): 是否启用边界修改增强。
                 boundary_args={}): # 保留兼容旧配置，当前训练流程不使用。
        # 相关参数
        self.trainsize = trainsize
        self.do_randomPeper = randomPeper
        self.do_boundary_modification = boundary_modification
        self.boundary_args = boundary_args
        # ==================== 新增：记录是否使用在线边缘推理 ====================
        self.use_online_edges = edge_root is None
        # =====================================================================

        # get filenames
        # 发现、筛选并正确配对训练所需的图像文件和真值（Ground Truth）标签文件。
        self.images = [image_root + f for f in os.listdir(image_root) if f.endswith('.jpg')]
        self.gts = [gt_root + f for f in os.listdir(gt_root) if f.endswith('.jpg')
                    or f.endswith('.png')]

        # ==================== 新增：当edge_root为None时，不加载边缘 ====================
        if edge_root is not None:
            self.edges = [os.path.join(edge_root, f) for f in os.listdir(edge_root) if f.endswith('.png')] if edge_root is not None else None
        else:
            self.edges = None  # 不加载边缘，将在线生成
        # =========================================================================

        self.images = sorted(self.images)   # 最终得到的self.images是一个包含图像完整路径的列表
        self.gts = sorted(self.gts)         # 最终得到的self.gts是一个包含标注文件完整路径的列表

        # ==================== 新增：只在有边缘时进行排序 ====================
        if self.edges is not None:
            self.edges = sorted(self.edges) if self.edges is not None else None     # 为边缘引导排序
        # ==================================================================

        # filter mathcing degrees of files
        # 筛选数据集，确保只保留那些原始图像和其对应的真值（Ground Truth）标签尺寸完全匹配的文件对
        self.filter_files()

        # transforms
        # 先对图像及其标注文件进行几何和形状上的数据增强，再对图像和标注文件分别进行最终处理
        import albumentations   # 使用 Albumentations 库创建的数据增强管道，能够同时对图像和其对应的分割掩码（mask）进行完全相同的随机几何变换
        self.aug_transform = albumentations.Compose([
            albumentations.RandomScale(scale_limit=0.25, p=0.5),    # 以 50% 的概率（p=0.5）对图像和掩码进行随机缩放，缩放范围在原尺寸的 75% 到 125% 之间。
            albumentations.HorizontalFlip(p=0.5),   # 以 50% 的概率进行水平翻转。
            albumentations.VerticalFlip(p=0.5),     # 以 50% 的概率进行垂直翻转。
            albumentations.Rotate(limit=15, p=0.5), # 以 50% 的概率在 -15 到 +15 度之间进行随机旋转。
            albumentations.RandomRotate90(p=0.5),   # 以 50% 的概率进行 90, 180 或 270 度的随机旋转。
            # albumentations.ElasticTransform(p=0.5),   # 这是一个被注释掉的操作，表示暂时不使用。弹性变换会像扭曲果冻一样对图像进行非刚性变形，是一种比较强的增强。
        ])
        self.img_transform = self.get_transform(mean, std)
        # self.gt_transform = transforms.Compose([
        #     transforms.Resize((self.trainsize, self.trainsize)),
        #     transforms.ToTensor()])
        self.gt_transform = transforms.Compose([
            # 1. 对标签图缩放时，必须使用最近邻插值(NEAREST)
            transforms.Resize((self.trainsize, self.trainsize), interpolation=Image.NEAREST),
            # 2. 将 PIL Image 转换为 NumPy 数组，再转换为 LongTensor，不进行归一化
            transforms.Lambda(lambda img: torch.from_numpy(np.array(img)).long())
        ])
        self.edge_transform = transforms.Compose([          # 为边缘图定义一个 transform，将边缘图转为Tensor
            transforms.Resize((self.trainsize, self.trainsize)),
            transforms.ToTensor()
        ])


        # get size of dataset
        # 获取数据集的样本量
        self.size = len(self.images)

    # forward
    '''
    输入参数 (Input Parameters):
        self: PolypObjDataset 这个类本身的实例。
        index (int): 一个整数，代表要从数据集中提取的样本的位置索引。如果数据集中有 N 个样本，index 的范围就是从 0 到 N-1。
    输出 (Return Value):
        data (dict): 一个 Python 字典，包含了处理完成、随时可以输入模型的数据。这个字典通常包含以下键值对：
            'image': 经过所有处理后的图像，是一个 PyTorch 张量。
            'gt': 对应的原始真值标签，也是一个 PyTorch 张量。
            'seg' (可选): 如果启用了边界修改增强，这个键将对应一个被修改过的真值标签张量。
    '''
    def __getitem__(self, index):
        data = {}
        # read imgs/gts/grads/depths
        image = self.rgb_loader(self.images[index])
        gt = self.mask_loader(self.gts[index])
        
        # ==================== 新增：根据是否使用在线边缘推理来处理 ====================
        if not self.use_online_edges:
            edge = self.binary_loader(self.edges[index])    # 读取边缘图，单通道灰度图
            image_size = image.size
            # data augumentation
            augmented = self.aug_transform(image=np.asarray(image),
                                           masks=[np.asarray(gt),
                                                  np.asarray(edge)])
            image = augmented['image']
            gt, edge = augmented['masks']

            image = colorEnhance(Image.fromarray(image))
            # gt = randomPeper(gt) if self.do_randomPeper else Image.fromarray(gt)
            gt = Image.fromarray(gt)
            edge = Image.fromarray(edge)

            image = self.img_transform(image)
            gt = self.gt_transform(gt)
            edge = self.edge_transform(edge) if edge is not None else torch.zeros((1, self.testsize, self.testsize), dtype=torch.float32)

            data['image'] = image
            data['gt'] = gt
            data['edge_map'] = edge
        else:
            # 在线边缘推理模式：不加载边缘，返回None
            image_size = image.size
            # data augumentation（只对图像和gt进行）
            augmented = self.aug_transform(image=np.asarray(image),
                                           masks=[np.asarray(gt)])
            image = augmented['image']
            gt = augmented['masks'][0]

            image = colorEnhance(Image.fromarray(image))
            # gt = randomPeper(gt) if self.do_randomPeper else Image.fromarray(gt)
            gt = Image.fromarray(gt)

            image = self.img_transform(image)
            gt = self.gt_transform(gt)

            data['image'] = image
            data['gt'] = gt
            data['edge_map'] = None  # 在线推理时，边缘图为None
        # ==================================================================================
        
        return data

    # 创建并返回一个标准化的图像预处理流程（pipeline）
    def get_transform(self, mean=None, std=None):
        mean = [0.485, 0.456, 0.406] if mean is None else mean
        std = [0.229, 0.224, 0.225] if std is None else std
        transform = transforms.Compose([
            transforms.Resize((self.trainsize, self.trainsize)),
            transforms.ToTensor(),
            transforms.Normalize(mean, std)])
        return transform

    # 筛选数据集，确保只保留那些原始图像和其对应的真值（Ground Truth）标签尺寸完全匹配的文件对
    def filter_files(self):
        assert len(self.images) == len(self.gts) and len(self.gts) == len(self.images)
        images = []
        gts = []
        for img_path, gt_path in zip(self.images, self.gts):
            img = Image.open(img_path)
            gt = Image.open(gt_path)
            if img.size == gt.size:
                images.append(img_path)
                gts.append(gt_path)
        self.images = images
        self.gts = gts

    # 加载数据集中的原始训练/测试的彩色图片。
    def rgb_loader(self, path):
        # 直接传递路径，Image.open 会自己管理文件的打开和关闭
        img = Image.open(path)
        return img.convert('RGB')

    # 用来加载标注文件(在分割中为二值图或灰度图)
    def binary_loader(self, path):
        with open(path, 'rb') as f:
            img = Image.open(f)
            return img.convert('L')

    def mask_loader(self, path):
        # 同样，直接传递路径
        img = Image.open(path)
        return img

    # 返回数据集中的样本总数
    def __len__(self):
        return self.size


# dataloader for training
# 融合了dataset和dataload的便捷数据处理加载函数
'''
eg.
    train_loader = get_loader(...)
    for batch_data in train_loader:
        # batch_data 就是一个批次的数据，可以直接送入模型
        images = batch_data['image']
        labels = batch_data['gt']
    ...
'''
def get_loader(image_root,
               gt_root,
               batchsize,
               trainsize,
               shuffle=True,
               num_workers=12,
               pin_memory=True):
    dataset = PolypObjDataset(image_root, gt_root, trainsize)
    data_loader = data.DataLoader(dataset=dataset,
                                  batch_size=batchsize,
                                  shuffle=shuffle,
                                  num_workers=num_workers,
                                  pin_memory=pin_memory)
    return data_loader


# test dataset and loader
# # 用于测试集dataset的类
class test_dataset(data.Dataset):
    def __init__(self, image_root, gt_root, edge_root=None, testsize=352, mean=None, std=None):
        super(test_dataset, self).__init__()
        self.testsize = testsize
        self.images = [image_root + f for f in os.listdir(image_root) if f.endswith('.jpg') or f.endswith('.png')]
        self.gts = [gt_root + f for f in os.listdir(gt_root) if f.endswith('.tif') or f.endswith('.png')]
        self.edges = [os.path.join(edge_root, f) for f in os.listdir(edge_root) if f.endswith('.png')] if edge_root is not None else None
        self.images = sorted(self.images)
        self.gts = sorted(self.gts)
        self.edges = sorted(self.edges) if self.edges is not None else None

        self.transform = self.get_transform(mean, std)
        # self.gt_transform = transforms.ToTensor()
        self.gt_transform = transforms.Compose([
            transforms.Resize((self.testsize, self.testsize), interpolation=Image.NEAREST),
            transforms.Lambda(lambda img: torch.from_numpy(np.array(img)).long())
        ])
        self.edge_transform = transforms.Compose([
            transforms.Resize((self.testsize, self.testsize)),
            transforms.ToTensor()
        ])
        self.size = len(self.images)
        self.index = 0

    def __getitem__(self, item):
        image = self.rgb_loader(self.images[item])  # 加载指定索引的RGB图像
        image_for_post = image.copy()   # 创建一个副本，用于后续处理
        # image = self.transform(image).unsqueeze(0)  # 对主图像进行变换，并增加批次维度

        gt = self.mask_loader(self.gts[item])     # 加载对应的真值标签
        edge = self.binary_loader(self.edges[item]) if self.edges is not None else None
        gt = self.gt_transform(gt)
        image = self.transform(image)
        edge = self.edge_transform(edge) if edge is not None else torch.zeros((1, self.testsize, self.testsize), dtype=torch.float32)
        name = self.images[item].split('/')[-1]     # 提取文件名

        # This is for initial predictor.
        image_for_post = self.get_transform()(image_for_post)   # 对副本图像也进行变换（注意这里调用 get_transform()() 是创建并立即使用）

        if name.endswith('.jpg'):   # # 统一文件名后缀为 .png
            name = name.split('.jpg')[0] + '.png'

        return {'image': image, 'gt': gt, 'edge_map': edge, 'name': name, 'image_path': self.images[item], 'image_for_post': image_for_post}       #  以字典形式返回所有需要的数据


    def get_transform(self, mean=None, std=None):
        mean = [0.485, 0.456, 0.406] if mean is None else mean
        std = [0.229, 0.224, 0.225] if std is None else std
        transform = transforms.Compose([
            transforms.Resize((self.testsize, self.testsize)),
            transforms.ToTensor(),
            transforms.Normalize(mean, std)])
        return transform

    def rgb_loader(self, path):
        # 直接传递路径，Image.open 会自己管理文件的打开和关闭
        img = Image.open(path)
        return img.convert('RGB')

    def binary_loader(self, path):
        with open(path, 'rb') as f:
            img = Image.open(f)
            return img.convert('L')

    def mask_loader(self, path):
        # 同样，直接传递路径
        img = Image.open(path)
        return img

    def __len__(self):
        return self.size
