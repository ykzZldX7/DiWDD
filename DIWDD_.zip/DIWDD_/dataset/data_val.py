import os
import albumentations
from PIL import Image
import torch.utils.data as data
import torchvision.transforms as transforms
import random
import numpy as np
from PIL import ImageEnhance
import torch
import torch.nn.functional as F


# Data augmentation helpers.
def cv_random_flip(img, label):
    flip_flag = random.randint(0, 3)
    if flip_flag == 1:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
        label = label.transpose(Image.FLIP_LEFT_RIGHT)
    elif flip_flag == 2:
        img = img.transpose(Image.FLIP_TOP_BOTTOM)
        label = label.transpose(Image.FLIP_TOP_BOTTOM)
    elif flip_flag == 3:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
        label = label.transpose(Image.FLIP_LEFT_RIGHT)
        img = img.transpose(Image.FLIP_TOP_BOTTOM)
        label = label.transpose(Image.FLIP_TOP_BOTTOM)
    return img, label

def randomCrop(image, label):
    border = 30
    image_width = image.size[0]
    image_height = image.size[1]
    crop_win_width = np.random.randint(image_width - border, image_width)
    crop_win_height = np.random.randint(image_height - border, image_height)
    random_region = (
        (image_width - crop_win_width) >> 1, (image_height - crop_win_height) >> 1, (image_width + crop_win_width) >> 1,
        (image_height + crop_win_height) >> 1)
    return image.crop(random_region), label.crop(random_region)

def randomRotation(image, label):
    mode = Image.BICUBIC
    if random.random() > 0.8:
        random_angle = np.random.randint(-15, 15)
        image = image.rotate(random_angle, mode)
        label = label.rotate(random_angle, Image.NEAREST)
    return image, label


def colorEnhance(image):
    bright_intensity = random.randint(5, 15) / 10.0
    image = ImageEnhance.Brightness(image).enhance(bright_intensity)
    contrast_intensity = random.randint(5, 15) / 10.0
    image = ImageEnhance.Contrast(image).enhance(contrast_intensity)
    color_intensity = random.randint(0, 20) / 10.0
    image = ImageEnhance.Color(image).enhance(color_intensity)
    sharp_intensity = random.randint(0, 30) / 10.0
    image = ImageEnhance.Sharpness(image).enhance(sharp_intensity)
    return image

def randomGaussian(image, mean=0.1, sigma=0.35):
    def gaussianNoisy(im, mean=mean, sigma=sigma):
        for _i in range(len(im)):
            im[_i] += random.gauss(mean, sigma)
        return im

    img = np.asarray(image)
    width, height = img.shape
    img = gaussianNoisy(img[:].flatten(), mean, sigma)
    img = img.reshape([width, height])
    return Image.fromarray(np.uint8(img))

def randomPeper(img):
    img = np.array(img)
    noiseNum = int(0.0015 * img.shape[0] * img.shape[1])
    for i in range(noiseNum):

        randX = random.randint(0, img.shape[0] - 1)

        randY = random.randint(0, img.shape[1] - 1)

        if random.randint(0, 1) == 0:

            img[randX, randY] = 0

        else:

            img[randX, randY] = 255
    return Image.fromarray(img)


# Training dataset.
class PolypObjDataset(data.Dataset):
    def __init__(self,
                 image_root,
                 gt_root,
                 edge_root,
                 trainsize,
                 mean=None,
                 std=None,
                 randomPeper=True,
                 boundary_modification=False,
                 boundary_args={}):
        self.trainsize = trainsize
        self.do_randomPeper = randomPeper
        self.do_boundary_modification = boundary_modification
        self.boundary_args = boundary_args
        self.use_online_edges = edge_root is None

        self.images = [image_root + f for f in os.listdir(image_root) if f.endswith('.jpg')]
        self.gts = [gt_root + f for f in os.listdir(gt_root) if f.endswith('.jpg')
                    or f.endswith('.png')]

        # Online edge inference does not load precomputed edge maps.
        if edge_root is not None:
            self.edges = [os.path.join(edge_root, f) for f in os.listdir(edge_root) if f.endswith('.png')] if edge_root is not None else None
        else:
            self.edges = None

        self.images = sorted(self.images)
        self.gts = sorted(self.gts)

        if self.edges is not None:
            self.edges = sorted(self.edges) if self.edges is not None else None

        self.filter_files()

        self.aug_transform = albumentations.Compose([
            albumentations.RandomScale(scale_limit=0.25, p=0.5),
            albumentations.HorizontalFlip(p=0.5),
            albumentations.VerticalFlip(p=0.5),
            albumentations.Rotate(limit=15, p=0.5),
            albumentations.RandomRotate90(p=0.5),
        ])
        self.img_transform = self.get_transform(mean, std)
        self.gt_transform = transforms.Compose([
            transforms.Resize((self.trainsize, self.trainsize), interpolation=Image.NEAREST),
            transforms.Lambda(lambda img: torch.from_numpy(np.array(img)).long())
        ])
        self.edge_transform = transforms.Compose([
            transforms.Resize((self.trainsize, self.trainsize)),
            transforms.ToTensor()
        ])

        self.size = len(self.images)

    def __getitem__(self, index):
        data = {}
        image = self.rgb_loader(self.images[index])
        gt = self.mask_loader(self.gts[index])
        
        if not self.use_online_edges:
            edge = self.binary_loader(self.edges[index])
            image_size = image.size
            augmented = self.aug_transform(image=np.asarray(image),
                                           masks=[np.asarray(gt),
                                                  np.asarray(edge)])
            image = augmented['image']
            gt, edge = augmented['masks']

            image = colorEnhance(Image.fromarray(image))
            gt = Image.fromarray(gt)
            edge = Image.fromarray(edge)

            image = self.img_transform(image)
            gt = self.gt_transform(gt)
            edge = self.edge_transform(edge) if edge is not None else torch.zeros((1, self.testsize, self.testsize), dtype=torch.float32)

            data['image'] = image
            data['gt'] = gt
            data['edge_map'] = edge
        else:
            image_size = image.size
            augmented = self.aug_transform(image=np.asarray(image),
                                           masks=[np.asarray(gt)])
            image = augmented['image']
            gt = augmented['masks'][0]

            image = colorEnhance(Image.fromarray(image))
            gt = Image.fromarray(gt)

            image = self.img_transform(image)
            gt = self.gt_transform(gt)

            data['image'] = image
            data['gt'] = gt
            data['edge_map'] = None
        
        return data

    def get_transform(self, mean=None, std=None):
        mean = [0.485, 0.456, 0.406] if mean is None else mean
        std = [0.229, 0.224, 0.225] if std is None else std
        transform = transforms.Compose([
            transforms.Resize((self.trainsize, self.trainsize)),
            transforms.ToTensor(),
            transforms.Normalize(mean, std)])
        return transform

    def filter_files(self):
        assert len(self.images) == len(self.gts) and len(self.gts) == len(self.images)
        images = []
        gts = []
        for img_path, gt_path in zip(self.images, self.gts):
            img = Image.open(img_path)
            gt = Image.open(gt_path)
            if img.size == gt.size:
                images.append(img_path)
                gts.append(gt_path)
        self.images = images
        self.gts = gts

    def rgb_loader(self, path):
        img = Image.open(path)
        return img.convert('RGB')

    def binary_loader(self, path):
        with open(path, 'rb') as f:
            img = Image.open(f)
            return img.convert('L')

    def mask_loader(self, path):
        img = Image.open(path)
        return img

    def __len__(self):
        return self.size


def get_loader(image_root,
               gt_root,
               batchsize,
               trainsize,
               shuffle=True,
               num_workers=12,
               pin_memory=True):
    dataset = PolypObjDataset(image_root, gt_root, trainsize)
    data_loader = data.DataLoader(dataset=dataset,
                                  batch_size=batchsize,
                                  shuffle=shuffle,
                                  num_workers=num_workers,
                                  pin_memory=pin_memory)
    return data_loader


# Test dataset.
class test_dataset(data.Dataset):
    def __init__(self, image_root, gt_root, edge_root=None, testsize=352, mean=None, std=None):
        super(test_dataset, self).__init__()
        self.testsize = testsize
        self.images = [image_root + f for f in os.listdir(image_root) if f.endswith('.jpg') or f.endswith('.png')]
        self.gts = [gt_root + f for f in os.listdir(gt_root) if f.endswith('.tif') or f.endswith('.png')]
        self.edges = [os.path.join(edge_root, f) for f in os.listdir(edge_root) if f.endswith('.png')] if edge_root is not None else None
        self.images = sorted(self.images)
        self.gts = sorted(self.gts)
        self.edges = sorted(self.edges) if self.edges is not None else None

        self.transform = self.get_transform(mean, std)
        self.gt_transform = transforms.Compose([
            transforms.Resize((self.testsize, self.testsize), interpolation=Image.NEAREST),
            transforms.Lambda(lambda img: torch.from_numpy(np.array(img)).long())
        ])
        self.edge_transform = transforms.Compose([
            transforms.Resize((self.testsize, self.testsize)),
            transforms.ToTensor()
        ])
        self.size = len(self.images)
        self.index = 0

    def __getitem__(self, item):
        image = self.rgb_loader(self.images[item])
        image_for_post = image.copy()

        gt = self.mask_loader(self.gts[item])
        edge = self.binary_loader(self.edges[item]) if self.edges is not None else None
        gt = self.gt_transform(gt)
        image = self.transform(image)
        edge = self.edge_transform(edge) if edge is not None else torch.zeros((1, self.testsize, self.testsize), dtype=torch.float32)
        name = self.images[item].split('/')[-1]

        # Used by the initial predictor branch.
        image_for_post = self.get_transform()(image_for_post)

        if name.endswith('.jpg'):
            name = name.split('.jpg')[0] + '.png'

        return {'image': image, 'gt': gt, 'edge_map': edge, 'name': name, 'image_path': self.images[item], 'image_for_post': image_for_post}


    def get_transform(self, mean=None, std=None):
        mean = [0.485, 0.456, 0.406] if mean is None else mean
        std = [0.229, 0.224, 0.225] if std is None else std
        transform = transforms.Compose([
            transforms.Resize((self.testsize, self.testsize)),
            transforms.ToTensor(),
            transforms.Normalize(mean, std)])
        return transform

    def rgb_loader(self, path):
        img = Image.open(path)
        return img.convert('RGB')

    def binary_loader(self, path):
        with open(path, 'rb') as f:
            img = Image.open(f)
            return img.convert('L')

    def mask_loader(self, path):
        img = Image.open(path)
        return img

    def __len__(self):
        return self.size
