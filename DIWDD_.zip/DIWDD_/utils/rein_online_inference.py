import os
import sys
from collections.abc import Sequence
from contextlib import contextmanager
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REIN_ROOT = PROJECT_ROOT / 'Rein'
MMSEG_ROOT = REIN_ROOT / 'mmsegmentation'

for root in (REIN_ROOT, MMSEG_ROOT):
    root = str(root)
    if root not in sys.path:
        sys.path.insert(0, root)

from mmengine.config import Config
from mmengine.runner.checkpoint import _load_checkpoint
from mmseg.apis import inference_model
from rein.utils import init_model


def resolve_project_path(path):
    path = Path(path)
    return str(path if path.is_absolute() else PROJECT_ROOT / path)


@contextmanager
def cwd(path):
    old_cwd = os.getcwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(old_cwd)


def load_backbone(checkpoint, backbone_path):
    backbone_weights = _load_checkpoint(backbone_path, map_location='cpu')
    weights = {f'backbone.{key}': value for key, value in backbone_weights.items()}
    if 'state_dict' in checkpoint:
        checkpoint['state_dict'].update(weights)
    else:
        checkpoint.update(weights)


class ReinOnlineInference:
    def __init__(self, config_path, checkpoint_path, backbone_path, device='cuda:0'):
        self.device = device
        self.config_path = resolve_project_path(config_path)
        self.checkpoint_path = resolve_project_path(checkpoint_path)
        self.backbone_path = resolve_project_path(backbone_path)
        self.model = self._load_model()

    def _load_model(self):
        with cwd(REIN_ROOT):
            cfg = Config.fromfile(self.config_path)
            if 'test_pipeline' not in cfg:
                cfg.test_pipeline = [
                    dict(type='LoadImageFromFile'),
                    dict(type='Resize', scale=(1920, 1080), keep_ratio=True),
                    dict(type='PackSegInputs'),
                ]

            model = init_model(cfg, self.checkpoint_path, device=self.device).to(self.device)
            state_dict = model.state_dict()
            load_backbone(state_dict, self.backbone_path)
            model.load_state_dict(state_dict)
            model.eval()
            return model

    def infer_batch(self, image_paths, device='cpu', output_size=None):
        image_paths = self._normalize_image_paths(image_paths)
        edge_maps = [
            self._edge_tensor_from_path(image_path, output_size)
            for image_path in image_paths
        ]
        return torch.cat(edge_maps, dim=0).to(device)

    @staticmethod
    def _normalize_image_paths(image_paths):
        if isinstance(image_paths, (str, Path)):
            return [str(image_paths)]
        if isinstance(image_paths, Sequence) and not torch.is_tensor(image_paths):
            return [str(path) for path in image_paths]
        raise TypeError('Rein online inference expects image path strings, not preprocessed tensors.')

    def _edge_tensor_from_path(self, image_path, output_size):
        edge_map = self._infer_edge_map(image_path)
        edge_tensor = torch.from_numpy(edge_map).float().unsqueeze(0).unsqueeze(0)
        if output_size is not None and tuple(edge_tensor.shape[-2:]) != tuple(output_size):
            edge_tensor = F.interpolate(edge_tensor, size=output_size, mode='nearest')
        if edge_tensor.max() > 0:
            edge_tensor = edge_tensor / 255.0
        return edge_tensor

    def _infer_edge_map(self, image_path):
        # Keep mmseg preprocessing on the raw image path from rein_config.py.
        with cwd(REIN_ROOT), torch.no_grad():
            result = inference_model(self.model, str(image_path))

        pred_mask = result.pred_sem_seg.data.squeeze().cpu().numpy().astype(np.uint8)
        pred_mask = self._resize_mask_to_original(pred_mask, image_path)
        return self._extract_edges(pred_mask)

    @staticmethod
    def _resize_mask_to_original(mask, image_path):
        with Image.open(image_path) as image:
            original_size = image.size

        mask_image = Image.fromarray(mask, mode='L')
        if mask_image.size != original_size:
            mask_image = mask_image.resize(original_size, resample=Image.NEAREST)
        return np.array(mask_image)

    @staticmethod
    def _extract_edges(mask, thickness=1):
        edge_map = np.zeros_like(mask, dtype=np.uint8)
        for class_id in range(1, 7):
            binary_mask = np.uint8(mask == class_id) * 255
            contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(edge_map, contours, -1, color=int(class_id), thickness=thickness)
        return edge_map
