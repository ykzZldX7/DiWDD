import glob
import logging
import os
import shutil
from pathlib import Path

import numpy as np
import torch
import torch.distributed as dist
import torch.nn.functional as F
from accelerate import Accelerator
from PIL import Image
from tqdm import tqdm

from model.train_val_forward import simple_train_val_forward
from utils.import_utils import fill_args_from_dict
from utils.train_utils import SmoothedValue


def exists(x):
    return x is not None


class Trainer:
    def __init__(
            self,
            model,
            train_loader,
            test_loader=None,
            train_val_forward_fn=simple_train_val_forward,
            gradient_accumulate_every=1,
            optimizer=None,
            scheduler=None,
            train_num_epoch=100,
            results_folder='output/trian_result',
            amp=False,
            fp16=False,
            split_batches=True,
            cfg=None,
    ):
        from accelerate import DistributedDataParallelKwargs

        mixed_precision = 'fp16' if (fp16 or amp) else 'no'
        ddp_kwargs = DistributedDataParallelKwargs(find_unused_parameters=True)
        self.accelerator = Accelerator(
            split_batches=split_batches,
            mixed_precision=mixed_precision,
            gradient_accumulation_steps=gradient_accumulate_every,
            kwargs_handlers=[ddp_kwargs],
        )
        self.accelerator.native_amp = amp

        self.model = model
        self.cfg = cfg
        self.train_val_forward_fn = train_val_forward_fn
        self.train_loader = train_loader
        self.test_loader = test_loader
        self.train_num_epoch = train_num_epoch
        self.cur_epoch = 0
        self.best_miou = 0.0

        self.val_every_epochs = cfg.get('val_every_epochs', 1) if cfg is not None else 1
        self.use_online_edge_inference = bool(cfg.get('use_online_edge_inference', False)) if cfg is not None else False
        self.online_edge_cache_ready = False
        self.online_edge_cache_dir = None
        self._rein_inference = None

        self.opt = optimizer
        self.scheduler = scheduler
        self.results_folder = Path(results_folder)
        if self.accelerator.is_main_process:
            self.results_folder.mkdir(parents=True, exist_ok=True)
        self.logger = self._create_local_logger(self.results_folder / 'log.txt')

        if self.use_online_edge_inference:
            self.online_edge_cache_dir = self.results_folder / 'tmp_online_edges'
            if self.accelerator.is_main_process and self.online_edge_cache_dir.exists():
                shutil.rmtree(self.online_edge_cache_dir)

        self._prepare_with_accelerator()
        self.accelerator.wait_for_everyone()

    def _prepare_with_accelerator(self):
        items = [
            ('model', self.model),
            ('opt', self.opt),
            ('scheduler', self.scheduler),
            ('train_loader', self.train_loader),
            ('test_loader', self.test_loader),
        ]
        names, objects = zip(*[(name, obj) for name, obj in items if obj is not None])
        prepared = self.accelerator.prepare(*objects)
        if len(objects) == 1:
            prepared = (prepared,)
        for name, obj in zip(names, prepared):
            setattr(self, name, obj)

    def _create_local_logger(self, log_path):
        logger = logging.getLogger(f'{__name__}.Trainer')
        logger.setLevel(logging.INFO)
        logger.propagate = False
        logger.handlers.clear()

        if self.accelerator.is_main_process:
            formatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s')
            file_handler = logging.FileHandler(log_path)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)

            stream_handler = logging.StreamHandler()
            stream_handler.setFormatter(formatter)
            logger.addHandler(stream_handler)
        else:
            logger.addHandler(logging.NullHandler())
        return logger

    def save(self, epoch, max_to_keep=3):
        if not self.accelerator.is_local_main_process:
            return

        numeric_ckpts = []
        for ckpt_file in glob.glob(str(self.results_folder / 'model-[0-9]*.pt')):
            stem = Path(ckpt_file).stem
            epoch_part = stem.replace('model-', '', 1)
            if epoch_part.isdigit():
                numeric_ckpts.append((int(epoch_part), ckpt_file))

        for _, ckpt_file in sorted(numeric_ckpts)[:-max_to_keep]:
            os.remove(ckpt_file)

        data = {
            'epoch': self.cur_epoch,
            'model': self.accelerator.get_state_dict(self.model),
            'scaler': self.accelerator.scaler.state_dict() if exists(self.accelerator.scaler) else None,
        }

        save_name = self.results_folder / f'model-{epoch}.pt'
        last_save_name = self.results_folder / f'model-{epoch}-last.pt'
        if save_name.exists():
            if last_save_name.exists():
                last_save_name.unlink()
            save_name.rename(last_save_name)

        torch.save(data, str(save_name))

    def load(self, resume_path=None, pretrained_path=None):
        device = self.accelerator.device
        if resume_path is not None:
            data = torch.load(resume_path, map_location=device)
            self.cur_epoch = data['epoch']
            if exists(self.accelerator.scaler) and exists(data.get('scaler')):
                self.accelerator.scaler.load_state_dict(data['scaler'])
        elif pretrained_path is not None:
            data = torch.load(pretrained_path, map_location=device)
        else:
            raise ValueError('Must specify resume_path or pretrained_path.')

        if self.scheduler is not None:
            for _ in range(self.cur_epoch):
                self.scheduler.step()

        model = self.accelerator.unwrap_model(self.model)
        model.load_state_dict(data['model'], strict=False)

    def _build_rein_inference(self):
        if self._rein_inference is not None:
            return self._rein_inference

        from utils.rein_online_inference import ReinOnlineInference

        self.accelerator.print('Initializing online Rein edge inference for validation cache...')
        self._rein_inference = ReinOnlineInference(
            config_path=self.cfg.rein_config,
            checkpoint_path=self.cfg.rein_checkpoint,
            backbone_path=self.cfg.backbone_checkpoint,
            device=self.accelerator.device,
        )
        return self._rein_inference

    def _load_cached_edge_batch(self, names, cache_dir, device, output_size):
        edge_maps = []
        for name in names:
            edge_path = Path(cache_dir) / os.path.basename(name)
            if not edge_path.is_file():
                raise FileNotFoundError(f'Cached online edge not found: {edge_path}')
            edge = Image.open(edge_path).convert('L')
            edge_tensor = torch.from_numpy(np.array(edge)).float().unsqueeze(0).unsqueeze(0) / 255.0
            if tuple(edge_tensor.shape[-2:]) != tuple(output_size):
                edge_tensor = F.interpolate(edge_tensor, size=output_size, mode='nearest')
            edge_maps.append(edge_tensor)
        return torch.cat(edge_maps, dim=0).to(device)

    def _save_online_edge_batch(self, edge_map, names, save_dir):
        os.makedirs(save_dir, exist_ok=True)
        edge_map = edge_map.detach().float().cpu().clamp(0, 1)
        for i, name in enumerate(names):
            edge_np = (edge_map[i, 0].numpy() * 255).astype(np.uint8)
            Image.fromarray(edge_np).save(Path(save_dir) / os.path.basename(name))

    def _cleanup_online_edge_cache(self):
        self.accelerator.wait_for_everyone()
        if self.accelerator.is_main_process and self.online_edge_cache_dir is not None and self.online_edge_cache_dir.exists():
            shutil.rmtree(self.online_edge_cache_dir)
            self.logger.info(f'Removed temporary online edge cache: {self.online_edge_cache_dir}')
        self.accelerator.wait_for_everyone()

    def _get_validation_edge_map(self, data, image, device, rein_inference=None, save_online_edge_dir=None,
                                 cached_edge_dir=None):
        if rein_inference is not None:
            image_paths = data.get('image_path')
            if image_paths is None:
                raise RuntimeError('Online Rein edge inference requires image_path from the validation dataset.')

            edge_map = rein_inference.infer_batch(
                image_paths,
                device=device,
                output_size=image.shape[-2:],
            )
            if edge_map.dim() == 3:
                edge_map = edge_map.unsqueeze(1)
            if save_online_edge_dir is not None:
                self._save_online_edge_batch(edge_map, data['name'], save_online_edge_dir)
            return edge_map

        if cached_edge_dir is not None:
            return self._load_cached_edge_batch(
                data['name'],
                cached_edge_dir,
                device=device,
                output_size=image.shape[-2:],
            )

        return data['edge_map'].to(device) if 'edge_map' in data else None

    @torch.inference_mode()
    def val_semantic(
            self,
            model,
            test_data_loader,
            accelerator,
            num_classes=7,
            save_to=None,
            rein_inference=None,
            save_online_edge_dir=None,
            cached_edge_dir=None,
            inference_profiler=None,
    ):
        model.eval()
        model = accelerator.unwrap_model(model)
        device = accelerator.device
        confusion_matrix = torch.zeros((num_classes, num_classes), device=device, dtype=torch.int64)

        for data in tqdm(test_data_loader, disable=not accelerator.is_main_process, desc='Validation/Testing'):
            image = data['image'].to(device)
            gt_batch = data['gt'].to(device, dtype=torch.long)
            edge_map = self._get_validation_edge_map(
                data,
                image,
                device,
                rein_inference=rein_inference,
                save_online_edge_dir=save_online_edge_dir,
                cached_edge_dir=cached_edge_dir,
            )

            val_out = self.train_val_forward_fn(
                model,
                image=image,
                edge_map=edge_map,
                gt_sizes=[(g.shape[-2], g.shape[-1]) for g in gt_batch],
                verbose=False,
                inference_profiler=inference_profiler,
            )

            for idx, (pred_logits, gt) in enumerate(zip(val_out['pred'], gt_batch)):
                pred_labels = torch.argmax(pred_logits.to(device), dim=0)
                if save_to is not None:
                    self._save_prediction(pred_labels, data['name'][idx], save_to)

                confusion_matrix += self._build_confusion_matrix(pred_labels, gt, num_classes)

        if accelerator.num_processes > 1:
            accelerator.wait_for_everyone()
            dist.all_reduce(confusion_matrix, op=dist.ReduceOp.SUM)

        metrics = self._compute_metrics(confusion_matrix) if accelerator.is_main_process else {
            'miou': 0.0,
            'pa': 0.0,
            'is_best': False,
        }
        accelerator.wait_for_everyone()
        return metrics, self.best_miou

    def _save_prediction(self, pred_labels, name, save_to):
        os.makedirs(save_to, exist_ok=True)
        pred_mask = pred_labels.cpu().numpy().astype('uint8')
        filename = os.path.basename(name)
        Image.fromarray(pred_mask).save(os.path.join(save_to, filename))

    @staticmethod
    def _build_confusion_matrix(pred_labels, gt, num_classes):
        gt_flat = gt.flatten()
        pred_flat = pred_labels.flatten()
        return torch.bincount(
            gt_flat * num_classes + pred_flat,
            minlength=num_classes ** 2,
        ).reshape(num_classes, num_classes)

    def _compute_metrics(self, confusion_matrix):
        intersection = torch.diag(confusion_matrix)
        union = confusion_matrix.sum(dim=1) + confusion_matrix.sum(dim=0) - intersection
        miou = (intersection / (union + 1e-6)).mean().item()
        pixel_accuracy = (intersection.sum() / (confusion_matrix.sum() + 1e-6)).item()
        is_best = miou > self.best_miou
        if is_best:
            self.best_miou = miou
        return {'miou': miou, 'pa': pixel_accuracy, 'is_best': is_best}

    def _run_validation(self):
        if not self.use_online_edge_inference:
            return self.val_semantic(self.model, self.test_loader, self.accelerator, num_classes=7)

        if not self.online_edge_cache_ready:
            rein_inference = self._build_rein_inference()
            metrics, best_miou = self.val_semantic(
                self.model,
                self.test_loader,
                self.accelerator,
                num_classes=7,
                rein_inference=rein_inference,
                save_online_edge_dir=self.online_edge_cache_dir,
            )
            self.accelerator.wait_for_everyone()
            self.online_edge_cache_ready = True
            self._rein_inference = None
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            self.logger.info(f'Online Rein edge cache ready: {self.online_edge_cache_dir}')
            return metrics, best_miou

        return self.val_semantic(
            self.model,
            self.test_loader,
            self.accelerator,
            num_classes=7,
            cached_edge_dir=self.online_edge_cache_dir,
        )

    def train(self):
        accelerator = self.accelerator
        try:
            for epoch in range(self.cur_epoch, self.train_num_epoch):
                self.cur_epoch = epoch
                self.model.train()
                loss_sm = SmoothedValue(window_size=10)

                with tqdm(total=len(self.train_loader), disable=not accelerator.is_main_process) as pbar:
                    for data in self.train_loader:
                        gt_long = data.pop('gt')
                        num_classes = self.model.model.class_num
                        data['gt_long'] = gt_long
                        data['gt_one_hot'] = F.one_hot(gt_long, num_classes=num_classes).permute(0, 3, 1, 2).float()

                        with accelerator.autocast(), accelerator.accumulate(self.model):
                            loss = fill_args_from_dict(self.train_val_forward_fn, data)(model=self.model)
                            accelerator.backward(loss)
                            accelerator.clip_grad_norm_(self.model.parameters(), 1.0)
                            self.opt.step()
                            self.opt.zero_grad()

                        loss_sm.update(loss.item())
                        pbar.set_description(
                            f'Epoch:{epoch}/{self.train_num_epoch} loss: '
                            f'{loss_sm.avg:.4f}({loss_sm.global_avg:.4f})'
                        )
                        pbar.update()

                if self.scheduler is not None:
                    self.scheduler.step()

                accelerator.wait_for_everyone()
                avg_loss = accelerator.gather(
                    torch.tensor([loss_sm.global_avg], device=accelerator.device)
                ).mean().item()
                self.logger.info(f'Epoch:{epoch}/{self.train_num_epoch} loss: {avg_loss:.4f}')

                if (epoch + 1) % self.val_every_epochs == 0 or epoch >= self.train_num_epoch * 0.95:
                    metrics, best_miou = self._run_validation()
                    if accelerator.is_main_process:
                        self.logger.info(
                            f'Epoch:{epoch}/{self.train_num_epoch} mIoU: {metrics["miou"]:.4f}, '
                            f'PA: {metrics["pa"]:.4f} (Best mIoU: {best_miou:.4f})'
                        )
                        if metrics['is_best']:
                            self.save('best')

                self.save(self.cur_epoch)
                accelerator.wait_for_everyone()
        finally:
            if self.use_online_edge_inference:
                self._cleanup_online_edge_cache()
        self.logger.info('training complete')
