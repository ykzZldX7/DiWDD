import argparse
from random import random

import numpy as np
import omegaconf
import torch
from omegaconf import OmegaConf

'''
add_args 是一个高度灵活的配置加载函数。它的主要工作是读取 YAML 配置文件，处理文件之间的继承关系，并允许用户通过两种不同的命令行参数方式来覆盖这些配置。
这个函数遵循一个明确的优先级顺序来确定最终的参数值：基础YAML < 主YAML < 普通命令行参数 < --set命令行参数(eg,--set model.params.lr=0.001)。
输入参数:
    parser (argparse.ArgumentParser 或 argparse.Namespace): 通常是一个 ArgumentParser 对象，函数会向其添加参数并用它来解析命令行输入。
输出 (返回值):
    config (omegaconf.dictconfig.DictConfig): 最终整合完毕的配置对象。
'''
def add_args(parser: argparse.ArgumentParser or argparse.Namespace) -> omegaconf.dictconfig.DictConfig:
    """
        Add arguments to the parser
        1. Read the config file and add the parameters to the parser
        2. Support using '__base__' to inherit the parameters from the base config file
        3. Override the parameters in the config file with the command line parameters
        4. Override the parameters in the config file with '--set' parameters, e.g. --set train.batch_size=4
    """
    if isinstance(parser, argparse.ArgumentParser):
        parser.add_argument('-c', '--config', type=str, help='config file path', default='configs/default.yaml')
        parser.add_argument('--set', nargs='+', type=str, help="override config file settings", default=[])
        args = parser.parse_args()
    elif isinstance(parser, argparse.Namespace):
        args = parser
    else:
        raise TypeError(f'parser must be argparse.ArgumentParser or argparse.Namespace, but got {type(parser)}')
    # read config file
    if args.config is not None:
        config = OmegaConf.load(args.config)
    else:
        config = OmegaConf.create()

    __base__ = config.get('__base__', [])
    config.__base__ = []
    # load config file and it's base config file
    while len(__base__) > 0:
        base_config = OmegaConf.load(__base__.pop(0))
        config = OmegaConf.merge(base_config, config)
        __base__ += base_config.get('__base__', [])
        config.__base__ = []
    # override config file settings
    for k, v in args.__dict__.items():
        cfg_v = config.get(k, None)
        config[k] = v if v is not None else cfg_v
    config = OmegaConf.merge(config, OmegaConf.from_dotlist(args.set)) if len(args.set) > 0 else config
    return config

'''
config_pretty 是一个配置打印工具。它的作用是将一个（可能深度嵌套的）OmegaConf 配置对象，以一种带有缩进、格式优美的、人类可读的方式打印到控制台。
输入参数:
    d (omegaconf.dictconfig.DictConfig): 需要打印的配置对象。
    indent (int, 默认值: 0): 用于控制当前打印层级的缩进量，主要在函数内部递归调用时使用。
输出:
    此函数没有 return 语句，不返回任何值。它的输出是直接打印到标准输出（您的终端或控制台）的文本。
'''
def config_pretty(d: omegaconf.dictconfig.DictConfig, indent=0):
    for key, value in d.items():
        print('\n' + '\t' * indent + str(key) + ":", end='')
        if isinstance(value, dict) or isinstance(value, omegaconf.dictconfig.DictConfig):
            config_pretty(value, indent + 1)
        else:
            print('\t' * (indent + 1) + str(value), end='')
