import importlib
from functools import partial

import omegaconf
import inspect

'''
工厂函数：根据一个配置字典 (config) 动态地创建并返回一个Python类的实例（对象），它是连接静态配置文件和动态程序代码的关键桥梁。
inputs:
     config (dict 或 omegaconf.dictconfig.DictConfig):包含实例化所需信息的配置字典
     target_key (str, 默认值: "name"):告诉函数在 config 字典中，哪一个键（key）对应的值是目标类的路径字符串。默认情况下，它会寻找名为 "name" 的键
     target_params_key (str, 默认值: "params"):告诉函数在 config 字典中，哪一个键（key）对应的值是初始化类时所需的参数字典。默认情况下，它会寻找名为 "params" 的键。
     **kwargs (任意数量的关键字参数): 这是一个非常有用的参数，它允许你在调用函数时传入额外的或者用于覆盖的参数。这些参数会被合并到从 config 文件中读取的 params 里。
'''
def instantiate_from_config(config, target_key="name", target_params_key="params", **kwargs):
    """
    Instantiate an object from a config dict.
    Args:
        config (dict, omegaconf.dictconfig.DictConfig): Config dict.
        target_key (str): Key of the target object.
        target_params_key (str): Key of the target object's parameters.
    Returns:
        object: Instantiated object.
    """
    if not isinstance(config, dict):
        config = dict(config)
    params = dict(config.get(target_params_key, dict()))
    merge_params = {**params, **kwargs}
    return get_obj_from_str(config[target_key])(**merge_params)


def recurse_instantiate_from_config(config, target_key="name", target_params_key="params", **kwargs):
    """
    Recursively instantiate an object from a config dict.
    Args:
        config (dict, omegaconf.dictconfig.DictConfig): Config dict.
        target_key (str): Key of the target object.
        target_params_key (str): Key of the target object's parameters.
    Returns:
        object: Instantiated object.
    """
    if not isinstance(config, dict):
        config = dict(config)
    params = dict(config.get(target_params_key, dict()))

    for k, v in params.items():
        if isinstance(v, dict) or isinstance(v, omegaconf.dictconfig.DictConfig):
            params[k] = recurse_instantiate_from_config(v, target_key, target_params_key)
    merge_params = {**params, **kwargs}
    return get_obj_from_str(config[target_key])(**merge_params)


'''
get_obj_from_str 函数的核心作用是根据一个字符串形式的完整路径，动态地导入并获取一个 Python 对象（通常是一个类或函数）。
它就像一个“寻宝机器人” 。你给它一张写着宝藏位置的地图（字符串路径，例如 'torch.optim.AdamW'），它就能帮你把那个宝藏（AdamW 这个类）从 Python 的模块世界里取出来。
inputs:
    string (str):
        格式: 一个字符串，表示一个 Python 对象的完整、点分隔的路径。
        示例: 'torch.optim.AdamW', 'model.b2.net.net'。
    reload (bool, 默认值: False):
        格式: 一个布尔值 (True 或 False)。
        作用: 一个可选的开关。如果设置为 True，函数会在导入模块之前，强制重新加载该模块。这在交互式开发（如 Jupyter Notebook）中非常有用，当你修改了模块的源代码后，可以确保加载的是最新版本的代码，而无需重启整个程序。在常规训练脚本中通常保持为 False。
outputs:
    一个 Python 对象 (例如，一个类、一个函数或一个变量)。
        重要提示: 它返回的是对象本身，而不是该对象的一个实例
        例如，如果输入是 'torch.optim.AdamW'，返回值是 AdamW 这个类，而不是 AdamW(...) 的一个实例。你需要自己用这个返回的类来创建实例
'''
def get_obj_from_str(string, reload=False):
    """
    Get an object from a string.
    Args:
        string (str): String of the object.
        reload (bool): Whether to reload the module.
    Returns:
        Class: Class of the object.
    """
    module, cls = string.rsplit(".", 1)
    if reload:
        module_imp = importlib.import_module(module)
        importlib.reload(module_imp)
    return getattr(importlib.import_module(module, package=None), cls)


class ClassInstance:
    """
    Create a class instance that can be called to create multiple instances of the target class.
    Use this class to create a class instead of a instance of a class, when you want to create in
    recurse_instantiate_from_config function.
    """

    def __new__(cls, target: str or type, **kwargs):
        if isinstance(target, str):
            target = get_obj_from_str(target)
        elif isinstance(target, type):
            pass
        else:
            raise TypeError(f'Invalid type for target_class: {type(target)}')
        return partial(target, **kwargs)
        # return target

# 从一个字典里挑出与目标函数参数匹配的项，并生成一个预填充这些参数的新函数，方便后续调用时只需要补充剩余参数。
def fill_args_from_dict(func, args_dict):
    args = inspect.getfullargspec(func).args
    args_dict = {k: v for k, v in args_dict.items() if k in args}
    return partial(func, **args_dict)