# tools/merge_weights.py
import torch
import argparse
from mmengine.runner.checkpoint import _load_checkpoint

def main():
    parser = argparse.ArgumentParser(description="Merge PEFT and backbone weights into a single checkpoint.")
    parser.add_argument('peft_checkpoint', help="Path to the checkpoint with PEFT module (Rein) and head weights.")
    parser.add_argument('backbone_checkpoint', help="Path to the frozen backbone weights.")
    parser.add_argument('output_checkpoint', help="Path to save the merged full checkpoint.")
    args = parser.parse_args()

    print(f"Loading PEFT/head weights from: {args.peft_checkpoint}")
    peft_weights = _load_checkpoint(args.peft_checkpoint, map_location='cpu')
    # PEFT checkpoint from MMSeg usually has weights inside 'state_dict'
    if 'state_dict' in peft_weights:
        peft_weights = peft_weights['state_dict']

    print(f"Loading backbone weights from: {args.backbone_checkpoint}")
    backbone_weights = _load_checkpoint(args.backbone_checkpoint, map_location='cpu')

    # Create the final state dictionary
    final_weights = {}

    # 1. Add backbone weights with the correct prefix
    print("Merging backbone weights...")
    for key, value in backbone_weights.items():
        final_weights[f'backbone.{key}'] = value

    # 2. Add PEFT and head weights (they should already have correct prefixes like 'reins' and 'decode_head')
    print("Merging PEFT and head weights...")
    final_weights.update(peft_weights)

    # 3. Save the merged checkpoint
    torch.save({'state_dict': final_weights}, args.output_checkpoint)
    print(f"Successfully merged weights and saved to: {args.output_checkpoint}")
    print(f"Total keys in merged checkpoint: {len(final_weights)}")

if __name__ == '__main__':
    main()