
import argparse
import os
import os.path as osp

os.chdir(osp.abspath(osp.dirname(osp.dirname(__file__))))
import sys

sys.path.append(os.curdir)

from mmengine.config import Config
from mmengine.runner.checkpoint import _load_checkpoint
from rein.utils import init_model
from mmseg.apis import inference_model
import rein
import tqdm
import mmengine
import torch
import numpy as np
from PIL import Image

def parse_args():
    parser = argparse.ArgumentParser(description="MMSeg inference: Save raw mask")
    parser.add_argument("config", help="Path to the training configuration file.")
    parser.add_argument("checkpoint", help="Path to the checkpoint file.")
    parser.add_argument("images", help="Directory or file path of images.")
    parser.add_argument("--suffix", default=".png", help="File suffix. Default '.png'.")
    parser.add_argument("--not-recursive", action='store_false', help="Recursive search.")
    parser.add_argument("--search-key", default="", help="Keyword filter.")
    parser.add_argument(
        "--backbone",
        default="checkpoints/dinov2_vitl14_converted_1024x1024.pth",
        help="Path to the backbone model checkpoint."
    )

    parser.add_argument("--save_dir", default="inference/infer_imgs", help="Directory to save masks.")
    parser.add_argument("--device", default="cuda:0", help="Device used for inference.")
    args = parser.parse_args()
    return args

def load_backbone(checkpoint: dict, backbone_path: str) -> None:
    converted_backbone_weight = _load_checkpoint(backbone_path, map_location="cpu")
    if "state_dict" in checkpoint:
        checkpoint["state_dict"].update(
            {f"backbone.{k}": v for k, v in converted_backbone_weight.items()}
        )
    else:
        checkpoint.update(
            {f"backbone.{k}": v for k, v in converted_backbone_weight.items()}
        )



def main():
    args = parse_args()

    # load config
    cfg = Config.fromfile(args.config)

    if "test_pipeline" not in cfg:
        cfg.test_pipeline = [
            dict(type="LoadImageFromFile"),
            dict(
                keep_ratio=True,
                scale=(1920, 1080), 
                type="Resize",
            ),
            dict(type="PackSegInputs"),
        ]
        
    model = init_model(cfg, args.checkpoint, device=args.device)
    model = model.cuda(args.device)
    state_dict = model.state_dict()
    load_backbone(state_dict, args.backbone)
    model.load_state_dict(state_dict)
    
    mmengine.mkdir_or_exist(args.save_dir)
    
    images = []
    if osp.isfile(args.images):
        images.append(args.images)
    elif osp.isdir(args.images):
        for im in mmengine.scandir(args.images, suffix=args.suffix, recursive=args.not_recursive):
            if args.search_key in im:
                images.append(osp.join(args.images, im))
    else:
        raise NotImplementedError()
        
    print(f"Collect {len(images)} images")
    
    for im_path in tqdm.tqdm(images):
        result = inference_model(model, im_path)
        
        pred_mask = result.pred_sem_seg.data.squeeze().cpu().numpy().astype(np.uint8)
        
        with Image.open(im_path) as original_img:
            w, h = original_img.size
            

        mask_img = Image.fromarray(pred_mask, mode='L')
        
        if mask_img.size != (w, h):
            mask_img = mask_img.resize((w, h), resample=Image.NEAREST)
            
        file_name = osp.splitext(osp.basename(im_path))[0] + ".png"
        save_path = osp.join(args.save_dir, file_name)
        mask_img.save(save_path)
        
    print(f"Results are saved in {args.save_dir}")

if __name__ == "__main__":
    main()


