import sys
from pathlib import Path

import torch
from torch import nn
from omegaconf import DictConfig
from utils.import_utils import instantiate_from_config, get_obj_from_str

_PROJECT_ROOT = Path(__file__).resolve().parents[1]
_LOCAL_DIFFUSION = _PROJECT_ROOT / 'denoising-diffusion-pytorch'
if _LOCAL_DIFFUSION.exists():
    sys.path.insert(0, str(_LOCAL_DIFFUSION))

from denoising_diffusion_pytorch.simple_diffusion import *
import numpy as np
from skimage import segmentation
import torch.nn.functional as F


class CondGaussianDiffusion(GaussianDiffusion):
    def __init__(
            self,
            model: UViT,
            *,
            image_size,
            channels=1,
            extra_channels=0,
            cond_channels=3,
            pred_objective='v',
            loss_type='l2',
            noise_schedule=logsnr_schedule_cosine,
            num_sample_steps=500,
            clip_sample_denoised=True,
            noise_d=None,
            noise_d_low=None,
            noise_d_high=None
    ):
        super(CondGaussianDiffusion, self).__init__(model,
                                                    image_size=image_size,
                                                    channels=channels,
                                                    pred_objective=pred_objective,
                                                    noise_schedule=noise_schedule,
                                                    noise_d=noise_d,
                                                    noise_d_low=noise_d_low,
                                                    noise_d_high=noise_d_high,
                                                    num_sample_steps=num_sample_steps,
                                                    clip_sample_denoised=clip_sample_denoised)

        if isinstance(loss_type, nn.Module):
            self.loss_fn = loss_type
            self.loss_type_str = 'custom'
        elif isinstance(loss_type, (dict, DictConfig)):
            self.loss_fn = instantiate_from_config(loss_type)
            self.loss_type_str = 'custom'
        elif loss_type not in ['l2', 'l1', 'l1+l2', 'mean(l1, l2)']:
            try:
                self.loss_fn = get_obj_from_str(loss_type)()
                self.loss_type_str = 'custom'
            except:
                raise NotImplementedError
        else:
            self.loss_fn = None
            self.loss_type_str = loss_type

        self.extra_channels = extra_channels
        self.cond_channels = cond_channels

    def _get_shape_attention_map(self, pred_logits, kernel_size=11):
        probs = F.softmax(pred_logits, dim=1)
        prob_bg = probs[:, 0:1, :, :]
        prob_fg = 1.0 - prob_bg

        padding = kernel_size // 2
        return F.max_pool2d(
            prob_fg, 
            kernel_size=kernel_size, 
            stride=1, 
            padding=padding
        )

    def _get_bbox_mask(self, pred_logits, bias=3):
        pred_labels = torch.argmax(pred_logits, dim=1, keepdim=True)
        prob_fg = (pred_labels != 0).float()
        
        batch_size, _, h, w = prob_fg.shape
        prob_fg_numpy = prob_fg.cpu().numpy()
        bbox_masks = np.zeros_like(prob_fg_numpy)
        
        for i in range(batch_size):
            binary_mask = (prob_fg_numpy[i, 0] > 0).astype(np.uint8)
            boundaries = segmentation.find_boundaries(binary_mask, mode="inner")
            if np.any(boundaries):
                rows, cols = np.where(boundaries)
                y_min, y_max = np.min(rows), np.max(rows)
                x_min, x_max = np.min(cols), np.max(cols)
                
                y_min_b = max(y_min - np.random.randint(0, bias), 0)
                y_max_b = min(y_max + 1 + np.random.randint(0, bias), h)
                x_min_b = max(x_min - np.random.randint(0, bias), 0)
                x_max_b = min(x_max + 1 + np.random.randint(0, bias), w)
                
                bbox_masks[i, 0, y_min_b:y_max_b, x_min_b:x_max_b] = 1.0
                
        return torch.from_numpy(bbox_masks).to(pred_logits.device, dtype=torch.float32)        
        
    def _create_proposal_image(self, original_image, prev_pred_mask, step_index):
        if step_index == 0:
            b, _, h, w = original_image.shape
            initial_map = torch.ones((b, 1, h, w), device=original_image.device)
            return {'attn_map': initial_map, 'bbox_map': initial_map}
        else:
            attn_map = self._get_shape_attention_map(prev_pred_mask, kernel_size=11)
            bbox_map = self._get_bbox_mask(prev_pred_mask, bias=3)
            return {'attn_map': attn_map, 'bbox_map': bbox_map}


    def forward(self, img, gt_long, cond_img, seg=None, extra_cond=None, edge_map=None, *args, **kwargs):
        b, channels, h, w = img.shape
        cond_channels = cond_img.shape[1]
        assert channels == self.channels
        assert h == w == self.image_size
        assert cond_channels == self.cond_channels

        img = normalize_to_neg_one_to_one(img)
        seg = normalize_to_neg_one_to_one(seg) if seg is not None else None
        extra_cond = default(extra_cond, torch.zeros((b, self.extra_channels, h, w), device=self.device))
        times = torch.zeros((img.shape[0],), device=self.device).float().uniform_(0, 1)
        
        loss = self.p_losses(img, times, gt_long, cond_img, seg, extra_cond,
                             edge_map=edge_map,
                             *args, **kwargs)
        return loss
        
    def p_losses(self, x_start, times, gt_long, cond_img, seg=None, extra_cond=None, edge_map=None, noise=None, *args, **kwargs):
        if seg is not None:
            x, log_snr = self.q_sample(x_start=seg, times=times, noise=noise)
        else:
            x, log_snr = self.q_sample(x_start=x_start, times=times, noise=noise)

        model_out = self.model(torch.cat([x, extra_cond], dim=1), log_snr, cond_img, edge_map=edge_map, is_training_mode=True)

        loss = self.loss_fn(predict=model_out, target_one_hot=x_start, target_long=gt_long)
        return loss

    @torch.no_grad()
    def sample(self,
               cond_img,
               extra_cond=None,
               verbose=True,
               edge_map=None,
               **kwargs):
        b, c, h, w = cond_img.shape
        extra_cond = default(extra_cond, torch.zeros((b, self.extra_channels, h, w), device=self.device))
        return self.p_sample_loop((b, self.channels, self.image_size, self.image_size), cond_img,
                                  extra_cond=extra_cond, verbose=verbose, edge_map=edge_map)

    @torch.no_grad()
    def p_sample_loop(self,
                      shape,
                      cond_img,
                      extra_cond,
                      verbose=True,
                      edge_map=None):
        img = torch.randn(shape, device=self.device)
        steps = torch.linspace(1., 0., self.num_sample_steps + 1, device=self.device)
        
        coarse_gt_for_proposal = torch.zeros(
            (shape[0], self.channels, shape[2], shape[3]), 
            device=self.device
        )

        for i in tqdm(range(self.num_sample_steps), desc='sampling loop time step', total=self.num_sample_steps, disable=not verbose):
            times = steps[i]
            times_next = steps[i + 1]
            proposal_attn = self._create_proposal_image(cond_img, coarse_gt_for_proposal, i)
            img, predicted_x_start = self.p_sample(
                img, cond_img, extra_cond, times, times_next, 
                edge_map=edge_map,
                proposal_img=proposal_attn 
            )
            coarse_gt_for_proposal = predicted_x_start.detach()
        img.clamp_(-1., 1.)     
        img = unnormalize_to_zero_to_one(img)   
        return img

    @torch.no_grad()
    def p_sample(self, x, cond, extra_cond, time, time_next, edge_map=None, proposal_img=None):
        model_mean, model_variance, predicted_x_start  = self.p_mean_variance(x=x, cond=cond, extra_cond=extra_cond, time=time,
                                                          time_next=time_next, edge_map=edge_map,
                                                                             proposal_img=proposal_img)
        if time_next == 0:
            return model_mean, predicted_x_start

        noise = torch.randn_like(x)
        return model_mean + sqrt(model_variance) * noise,predicted_x_start

    def p_mean_variance(self, x, cond, extra_cond, time, time_next, edge_map=None, proposal_img=None):
        log_snr = self.log_snr(time)
        log_snr_next = self.log_snr(time_next)
        c = -expm1(log_snr - log_snr_next)

        squared_alpha, squared_alpha_next = log_snr.sigmoid(), log_snr_next.sigmoid()
        squared_sigma, squared_sigma_next = (-log_snr).sigmoid(), (-log_snr_next).sigmoid()

        alpha, sigma, alpha_next = map(sqrt, (squared_alpha, squared_sigma, squared_alpha_next))

        batch_log_snr = repeat(log_snr, ' -> b', b=x.shape[0])
        pred = self.model.sample_unet(torch.cat([x, extra_cond], dim=1),
                                      batch_log_snr, cond, edge_map=edge_map, proposal_img=proposal_img, is_training_mode=False)

        if self.pred_objective == 'v':
            x_start = alpha * x - sigma * pred

        elif self.pred_objective == 'eps':
            x_start = (x - sigma * pred) / alpha

        elif self.pred_objective == 'x0':
            x_start = pred.tanh()

        x_start.clamp_(-1., 1.)
        model_mean = alpha_next * (x * (1 - c) / alpha + c * x_start)

        posterior_variance = squared_sigma_next * c

        return model_mean, posterior_variance, x_start
