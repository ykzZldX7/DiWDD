import torch
from torch import nn
import torch.nn.functional as F


def normalize_to_01(x):
    return (x - x.min()) / (x.max() - x.min() + 1e-8)


def simple_train_val_forward(model: nn.Module, gt_long=None, gt_one_hot=None, image=None, edge_map=None, **kwargs):
    if model.training:
        assert gt_long is not None and gt_one_hot is not None and image is not None
        return model(gt_one_hot, gt_long, image, edge_map=edge_map, **kwargs)

    gt_sizes = kwargs.pop('gt_sizes', None)
    inference_profiler = kwargs.pop('inference_profiler', None)
    if inference_profiler is None:
        pred_tensor = model.sample(image, edge_map=edge_map, **kwargs)
    else:
        inference_profiler.start_batch(image.shape[0], image.device)
        try:
            pred_tensor = inference_profiler.profile_call(
                model,
                lambda: model.sample(image, edge_map=edge_map, **kwargs),
            )
        finally:
            inference_profiler.end_batch(image.device)

    if gt_sizes is None:
        pred_list = [pred for pred in pred_tensor]
    else:
        pred_list = [
            F.interpolate(pred.unsqueeze(0), size=size, mode='bilinear', align_corners=False).squeeze(0)
            for pred, size in zip(pred_tensor, gt_sizes)
        ]

    return {
        "image": image,
        "pred": pred_list,
        "gt": gt_long if gt_long is not None else None,
    }
