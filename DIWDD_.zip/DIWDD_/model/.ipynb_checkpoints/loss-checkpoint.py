import torch
import torch.nn as nn
import torch.nn.functional as F


class DiceLoss(nn.Module):
    def __init__(self, weight=None):
        super(DiceLoss, self).__init__()
        if weight is not None:
            weight = torch.Tensor(weight)
            self.weight = weight / torch.sum(weight)  # Normalized weight
        self.smooth = 1e-5

    def forward(self, predict, target):
        N, C = predict.size()[:2]
        predict = predict.view(N, C, -1)  # (N, C, *)
        target = target.view(N, 1, -1)  # (N, 1, *)

        predict = F.softmax(predict, dim=1)  # (N, C, *) ==> (N, C, *)
        target_onehot = torch.zeros(predict.size()).cuda()  # (N, 1, *) ==> (N, C, *)
        target_onehot.scatter_(1, target, 1)  # (N, C, *)

        intersection = torch.sum(predict * target_onehot, dim=2)  # (N, C)
        union = torch.sum(predict.pow(2), dim=2) + torch.sum(target_onehot, dim=2)  # (N, C)
        dice_coef = (2 * intersection + self.smooth) / (union + self.smooth)  # (N, C)

        if hasattr(self, 'weight'):
            if self.weight.type() != predict.type():
                self.weight = self.weight.type_as(predict)
                dice_coef = dice_coef * self.weight * C  # (N, C)
        dice_loss = 1 - torch.mean(dice_coef)  # 1

        return dice_loss

class CrossEntropyLoss(nn.Module):

    def __init__(self, weight=None, ignore_index=-100):
        super(CrossEntropyLoss, self).__init__()
        if weight is not None:
            self.weight = torch.Tensor(weight)
        else:
            self.weight = None
        self.ignore_index = ignore_index

    def forward(self, predict, target):
        if self.weight is not None:
            if self.weight.type() != predict.type():
                self.weight = self.weight.type_as(predict)
        loss = F.cross_entropy(
            predict,
            target,
            weight=self.weight,
            ignore_index=self.ignore_index,
            reduction='mean' # 计算批次中所有像素损失的平均值
        )

        return loss


# 在 model/loss.py 文件中，修改 WeightedMSELoss 类

import torch
import torch.nn as nn
import torch.nn.functional as F


class WeightedMSELoss(nn.Module):
    def __init__(self, weight=None, ignore_index=None):
        super(WeightedMSELoss, self).__init__()
        self.ignore_index = ignore_index
        if weight is not None:
            self.class_weights = torch.tensor(weight)
        else:
            self.class_weights = None

    def forward(self, predict, target_one_hot, target_long):

        loss_per_pixel = F.mse_loss(predict, target_one_hot, reduction='none')
        if self.class_weights is not None:
            device = predict.device
            if self.class_weights.device != device:
                self.class_weights = self.class_weights.to(device)
            weight_map = self.class_weights[target_long.long()].unsqueeze(1)
            loss_per_pixel = loss_per_pixel * weight_map
        if self.ignore_index is not None:
            valid_mask = (target_long != self.ignore_index)
            loss_per_pixel = loss_per_pixel * valid_mask.unsqueeze(1)
            num_channels = predict.shape[1]
            num_valid_pixels = valid_mask.sum()
            num_valid_elements = num_valid_pixels * num_channels
            loss = loss_per_pixel.sum() / (num_valid_elements + 1e-8)
        else:
            loss = loss_per_pixel.mean()

        return loss

class CompositeLoss(nn.Module):


    def __init__(self, mse_weight=1.0, ce_weight=1.0, mse_params=None, ce_params=None):
        super().__init__()
        self.mse_weight = mse_weight
        self.ce_weight = ce_weight
        mse_params = mse_params if mse_params is not None else {}
        self.mse_loss = WeightedMSELoss(**mse_params)
        ce_params = ce_params if ce_params is not None else {}
        self.ce_loss = CrossEntropyLoss(**ce_params)
        print(f"CompositeLoss initialized with MSE weight: {self.mse_weight} and CE weight: {self.ce_weight}")

    def forward(self, predict, target_one_hot, target_long):
        loss_mse = self.mse_loss(predict, target_one_hot, target_long)
        loss_ce = self.ce_loss(predict, target_long)
        total_loss = (self.mse_weight * loss_mse) + (self.ce_weight * loss_ce)

        return total_loss

# =====================================================================================================================