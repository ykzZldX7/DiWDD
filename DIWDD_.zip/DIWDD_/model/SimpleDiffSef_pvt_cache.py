import torch
from tqdm import tqdm

from model.SimpleDiffSef import (
    CondGaussianDiffusion as BaseCondGaussianDiffusion,
    default,
    expm1,
    repeat,
    sqrt,
    unnormalize_to_zero_to_one,
)


class CondGaussianDiffusion(BaseCondGaussianDiffusion):
    @torch.no_grad()
    def sample(
            self,
            cond_img,
            extra_cond=None,
            verbose=True,
            edge_map=None,
            pvt_cache_steps=1,
            use_skip_sampling=False,
            skip_sampling_stride=2,
            **kwargs):
        b, c, h, w = cond_img.shape
        extra_cond = default(extra_cond, torch.zeros((b, self.extra_channels, h, w), device=self.device))
        return self.p_sample_loop(
            (b, self.channels, self.image_size, self.image_size),
            cond_img,
            extra_cond=extra_cond,
            verbose=verbose,
            edge_map=edge_map,
            pvt_cache_steps=pvt_cache_steps,
            use_skip_sampling=use_skip_sampling,
            skip_sampling_stride=skip_sampling_stride,
        )

    @staticmethod
    def _sampling_step_pairs(num_sample_steps, use_skip_sampling=False, skip_sampling_stride=2):
        if not use_skip_sampling:
            return [(i, i + 1) for i in range(num_sample_steps)]

        skip_sampling_stride = max(1, int(skip_sampling_stride))
        start_indices = list(range(0, num_sample_steps, skip_sampling_stride))
        if not start_indices:
            start_indices = [0]

        pairs = []
        for index, start_index in enumerate(start_indices):
            if index + 1 < len(start_indices):
                end_index = start_indices[index + 1]
            else:
                end_index = num_sample_steps
            pairs.append((start_index, end_index))

        return pairs

    @torch.no_grad()
    def p_sample_loop(
            self,
            shape,
            cond_img,
            extra_cond,
            verbose=True,
            edge_map=None,
            pvt_cache_steps=1,
            use_skip_sampling=False,
            skip_sampling_stride=2):
        img = torch.randn(shape, device=self.device)
        steps = torch.linspace(1., 0., self.num_sample_steps + 1, device=self.device)
        sampling_step_pairs = self._sampling_step_pairs(
            self.num_sample_steps,
            use_skip_sampling=use_skip_sampling,
            skip_sampling_stride=skip_sampling_stride,
        )
        pvt_cache_steps = max(1, int(pvt_cache_steps))
        cached_backbone_features = None

        coarse_gt_for_proposal = torch.zeros(
            (shape[0], self.channels, shape[2], shape[3]),
            device=self.device,
        )

        for sample_call_index, (i, next_i) in enumerate(tqdm(
                sampling_step_pairs,
                desc='sampling loop time step',
                total=len(sampling_step_pairs),
                disable=not verbose)):
            times = steps[i]
            times_next = steps[next_i]
            proposal_attn = self._create_proposal_image(cond_img, coarse_gt_for_proposal, i)
            use_cached_features = cached_backbone_features is not None and sample_call_index >= pvt_cache_steps

            img, predicted_x_start, backbone_features = self.p_sample(
                img,
                cond_img,
                extra_cond,
                times,
                times_next,
                edge_map=edge_map,
                proposal_img=proposal_attn,
                cached_backbone_features=cached_backbone_features if use_cached_features else None,
            )
            if not use_cached_features:
                cached_backbone_features = tuple(feature.detach() for feature in backbone_features)
            coarse_gt_for_proposal = predicted_x_start.detach()

        img.clamp_(-1., 1.)
        img = unnormalize_to_zero_to_one(img)
        return img

    @torch.no_grad()
    def p_sample(
            self,
            x,
            cond,
            extra_cond,
            time,
            time_next,
            edge_map=None,
            proposal_img=None,
            cached_backbone_features=None):
        model_mean, model_variance, predicted_x_start, backbone_features = self.p_mean_variance(
            x=x,
            cond=cond,
            extra_cond=extra_cond,
            time=time,
            time_next=time_next,
            edge_map=edge_map,
            proposal_img=proposal_img,
            cached_backbone_features=cached_backbone_features,
        )
        if time_next == 0:
            return model_mean, predicted_x_start, backbone_features

        noise = torch.randn_like(x)
        return model_mean + sqrt(model_variance) * noise, predicted_x_start, backbone_features

    def p_mean_variance(
            self,
            x,
            cond,
            extra_cond,
            time,
            time_next,
            edge_map=None,
            proposal_img=None,
            cached_backbone_features=None):
        log_snr = self.log_snr(time)
        log_snr_next = self.log_snr(time_next)
        c = -expm1(log_snr - log_snr_next)

        squared_alpha, squared_alpha_next = log_snr.sigmoid(), log_snr_next.sigmoid()
        squared_sigma, squared_sigma_next = (-log_snr).sigmoid(), (-log_snr_next).sigmoid()

        alpha, sigma, alpha_next = map(sqrt, (squared_alpha, squared_sigma, squared_alpha_next))

        batch_log_snr = repeat(log_snr, ' -> b', b=x.shape[0])
        model_input = torch.cat([x, extra_cond], dim=1)

        if cached_backbone_features is None:
            backbone_features = self.model.backbone(model_input, batch_log_snr, cond)
        else:
            backbone_features = cached_backbone_features

        pred = self.model.decode_head(
            backbone_features,
            batch_log_snr,
            model_input,
            edge_map=edge_map,
            proposal_img=proposal_img,
            is_training_mode=False,
        )

        if self.pred_objective == 'v':
            x_start = alpha * x - sigma * pred
        elif self.pred_objective == 'eps':
            x_start = (x - sigma * pred) / alpha
        elif self.pred_objective == 'x0':
            x_start = pred.tanh()

        x_start.clamp_(-1., 1.)
        model_mean = alpha_next * (x * (1 - c) / alpha + c * x_start)

        posterior_variance = squared_sigma_next * c

        return model_mean, posterior_variance, x_start, backbone_features
